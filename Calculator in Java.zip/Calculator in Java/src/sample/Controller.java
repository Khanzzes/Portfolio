package sample;

import javafx.event.ActionEvent;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;

public class Controller {
    public double calculate(double num1, double num2, String operator) {
        switch (operator) {
            case "%":
                return num1 * 0.01;
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "X":
                return num1 * num2;
            case "/":
                if (num2 == 0)
                    return 0;
                return num1 / num2;
            default:
                return 0;

            case "Ln":
                return Math.log(num1);
            case "Log10":
                return Math.log10(num1);

            case "Pi":
                return 3.14;
            case "1/x":
                return 1 / num1;

            case "x^2":
                return Math.pow(num1, 2);
            case "x^3":
                return Math.pow(num1, 3);
            case "x^y":
                return Math.pow(num1, num2);
            case "10^x":
                return Math.pow(10, num1);

            case "x^(1/2)":
                return Math.sqrt(num1);

            case "sin":
                double b = Math.toRadians(num1);
                return Math.sin(b);
            case "cos":
                double c = Math.toRadians(num1);
                return Math.cos(c);
            case "tan":
                double d = Math.toRadians(num1);
                return Math.tan(d);
            case "sinh":
                return Math.sinh(num1);
            case "cosh":
                return Math.cosh(num1);
            case "tanh":
                return Math.tanh(num1);






    }
}



}

