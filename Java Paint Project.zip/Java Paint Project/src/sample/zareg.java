package sample;

public class zareg {

}
